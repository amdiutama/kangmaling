# elite

script ini di buat oleh dapunta dan Krn di delete dari github saya lanjutkan script ini

# commad.

pkg install git python2

pip2 install bs4

rm -rf elite

git clone https://github.com/Hakiki-XC/elite

cd elite

python2 elite.pyc


# thanks udh pakai

# makasi udh pakai btw SC baru update ketik ae git pull
